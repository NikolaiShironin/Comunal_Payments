﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Comunalka.Classes;

namespace Comunalka.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageEdit.xaml
    /// </summary>
    public partial class PageEdit : Page
    {
        private Building _currentUser = new Building();
        public PageEdit(Building selectedUser)
        {
            InitializeComponent();
            CmbIDOwner.ItemsSource = Comunal_paymentsEntities.GetContext().Owner.ToList();
            CmbIDOwner.SelectedValuePath = "idOwner";
            CmbIDOwner.DisplayMemberPath = "FIO";

            CmbIDResiding.ItemsSource = Comunal_paymentsEntities.GetContext().Residing.ToList();
            CmbIDResiding.SelectedValuePath = "idResiding";
            CmbIDResiding.DisplayMemberPath = "FIO";

            if (selectedUser != null)
                _currentUser = selectedUser;
            DataContext = _currentUser;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder(); //объект для сообщения об ошибке

            //проверка полей объекта
            if (string.IsNullOrWhiteSpace(_currentUser.Adress))
                error.AppendLine("Укажите Адрес");
            if (string.IsNullOrWhiteSpace(_currentUser.UnicNumber))
                error.AppendLine("Укажите Уникальный номер");
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            //если пользователь новый
            if (_currentUser.idBuilding == 0)
                Comunal_paymentsEntities.GetContext().Building.Add(_currentUser); //добавить в контекст
            try
            {
                Comunal_paymentsEntities.GetContext().SaveChanges(); // сохранить изменения
                                                             // dbISP19AEntities.GetContext().ChangeTracker.Entries().ToList().ForEach(p => p.Reload());
                MessageBox.Show("Данные сохранены");
                ClassFrame.frmObj.Navigate(new PageComun());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
    
}
