﻿using Comunalka.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Comunalka.Pages
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    public partial class Main : Page
    {
        public Main()
        {
            InitializeComponent();
        }

        private void BtnToTable_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageComun());
        }

        private void BtnToWord_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new WordHelper((sender as Button).DataContext as Building));
        }

        private void BtnFunction_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageFunction());
        }
    }
}
