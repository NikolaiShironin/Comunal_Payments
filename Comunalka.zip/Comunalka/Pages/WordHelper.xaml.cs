﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Word = Microsoft.Office.Interop.Word;
using Comunalka.Classes;
using System.Security.Cryptography.X509Certificates;
using System.IO;
using System.Runtime.InteropServices;

namespace Comunalka.Pages
{
    public partial class WordHelper : Page
    {
        private FileInfo _fileInfo;
        public WordHelper(string fileName)
        {
            if (File.Exists(fileName))
            {
                _fileInfo = new FileInfo(fileName); 
            }
            else
            {
                throw new ArgumentException("Файл не найден");
            }
        }
        private Building _currentUser = new Building();
        public WordHelper(Building selectedUser)
        {
            InitializeComponent();
            CmbIDOwner.ItemsSource = Comunal_paymentsEntities.GetContext().Owner.ToList();
            CmbIDOwner.SelectedValuePath = "idOwner";
            CmbIDOwner.DisplayMemberPath = "FIO";

            CmbIDResiding.ItemsSource = Comunal_paymentsEntities.GetContext().Residing.ToList();
            CmbIDResiding.SelectedValuePath = "idResiding";
            CmbIDResiding.DisplayMemberPath = "FIO";

            CmbAdress.ItemsSource = Comunal_paymentsEntities.GetContext().Building.ToList();
            CmbAdress.SelectedValuePath = "idBuilding";
            CmbAdress.DisplayMemberPath = "Adress";

            CmbPrice.ItemsSource = Comunal_paymentsEntities.GetContext().Building.ToList();
            CmbPrice.SelectedValuePath = "idBuilding";
            CmbPrice.DisplayMemberPath = "Price";

            if (selectedUser != null)
                _currentUser = selectedUser;
            DataContext = _currentUser;
        }
        private void BtnOut_Click(object sender, RoutedEventArgs e)
        {
            var helper = new WordHelper("Documents\\Arenda.docx");
            var items = new Dictionary<string, string>
            {
                { "<RES>", CmbIDResiding.Text },
                { "<OWN>", CmbIDOwner.Text},
                { "<ADRES>", CmbAdress.Text},
                { "<PRICE>", CmbPrice.Text},
            };
            helper.Process(items);
        }
        internal bool Process(Dictionary<string, string> items)
        {
            try
            {
                var app = new Word.Application();
                Object file = _fileInfo.FullName;
                Object missing = Type.Missing;
                app.Documents.Open(file);
                foreach (var item in items)
                {
                    Word.Find find = app.Selection.Find;
                    find.Text = item.Key;
                    find.Replacement.Text = item.Value;
                    Object wrap = Word.WdFindWrap.wdFindContinue;
                    Object replace = Word.WdReplace.wdReplaceAll;
                    find.Execute(FindText: Type.Missing,
                        MatchCase: false,
                        MatchWholeWord: false,
                        MatchWildcards: false,
                        MatchSoundsLike: missing,
                        MatchAllWordForms: false,
                        Forward: true,
                        Wrap: wrap,
                        Format: false,
                        ReplaceWith: missing, Replace: replace);
                }

                return true;
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
            return false;
        }
    }
}
